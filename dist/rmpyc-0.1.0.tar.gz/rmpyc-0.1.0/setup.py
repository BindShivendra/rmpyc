# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['rmpyc']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['rmpyc = rmpyc:main']}

setup_kwargs = {
    'name': 'rmpyc',
    'version': '0.1.0',
    'description': 'remove .pyc files',
    'long_description': None,
    'author': 'BindShivendra',
    'author_email': 'shivendra.bind@outlook.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
